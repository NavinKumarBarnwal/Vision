window.onload=initAll;

var sendbutton;
function initAll(){
    sendbutton = document.getElementById("send");
    sendbutton.onclick = sendmsg;
}

function sendmsg(){
    alert();
}